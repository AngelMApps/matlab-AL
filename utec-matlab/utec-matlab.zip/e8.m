%i
%A=[-2 0 0 1;1 1 3 0;0 -2 -2 1;1 0 -1 -1]
C=[1 0 2;1 1 3;0 1 1]
det(C)
%ii
%<1,6,4>=a<2,3,1>+b<1,0,-1>
%<1,6,4>=<2a,3a,a>+<b,0,-b>
%2a+b=1
%3a+0=1
%a-b=4
%es falso
%ya que no a,b,c no es igual a Cero
