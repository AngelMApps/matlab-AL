AB=[5 4;-2 3]
B=[7 3;2 1]

A=AB*inv(B)
